<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Estanteria extends Model
{
    //
}
