<template>
    <ul class="list-group list-group-flush">
        <li class="list-group-item">Farmaco:</li>
        <li class="list-group-item">indicacion</li>
    </ul>
</template>

<script>
    export default {
        name: "RecetaContentComponent"
    }
</script>

<style scoped>

</style>