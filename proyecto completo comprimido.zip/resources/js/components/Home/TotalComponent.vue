<template>
    <div class="card">
        <div class="card-header">Total Recaudo</div>
        <div class="card-body">
            $ XXXXXXX.XX
        </div>
    </div>
</template>

<script>
    export default {
        name: "TotalComponent"
    }
</script>

<style scoped>

</style>