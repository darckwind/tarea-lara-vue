<template>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                Cliente nombre:
            </div>
            <mascota-component></mascota-component>
            <a href="#" class="btn btn-danger">Delete</a>
        </div>
    </div>

</template>

<script>
    export default {
        name: "ClientComponent"
    }
</script>

<style scoped>

</style>