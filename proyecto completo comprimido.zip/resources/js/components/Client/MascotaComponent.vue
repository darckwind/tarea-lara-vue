<template>
        <ul class="list-group list-group-flush">
            <li class="list-group-item">Nombre mascota:</li>
        </ul>
</template>

<script>
    export default {
        name: "MascotaComponent"
    }
</script>

<style scoped>

</style>