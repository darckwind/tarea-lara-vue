@extends('layouts.app')

@section('content')

    <home-component></home-component>

@endsection
