@extends('layouts.app')

@section('content')
    <home-client-component></home-client-component>

@endsection
